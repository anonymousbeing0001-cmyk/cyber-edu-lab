const chatWindow = document.getElementById("chat-window");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

function addMessage(text, type) {
    const div = document.createElement("div");
    div.classList.add("message", type === "user" ? "user-msg" : "ai-msg");
    div.textContent = text;
    chatWindow.appendChild(div);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}

function sendMessage() {
    const text = userInput.value.trim();
    if (!text) return;
    addMessage(text, "user");
    userInput.value = "";
    simulateAIResponse(text);
}

function simulateAIResponse(userText) {
    const typingDiv = document.createElement("div");
    typingDiv.classList.add("message", "ai-msg");
    typingDiv.textContent = "Wolfpack AI is typing...";
    chatWindow.appendChild(typingDiv);
    chatWindow.scrollTop = chatWindow.scrollHeight;

    setTimeout(() => {
        chatWindow.removeChild(typingDiv);
        addMessage("This is a simulated AI response to: " + userText, "ai");
    }, 800 + Math.random() * 1000); // 0.8–1.8 seconds delay
}

sendBtn.addEventListener("click", sendMessage);
userInput.addEventListener("keypress", e => {
    if (e.key === "Enter") sendMessage();
});